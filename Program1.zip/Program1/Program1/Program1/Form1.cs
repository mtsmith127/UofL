﻿//This program takes input from a user regarding a paint job. It uses a button click event to calculate and output information about the cost and specs of the job.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private const double SQUARE_FEET_COVERED = 275; //Constant declaring how much square ft is covered by 1 coat.
        private const double HOURS_OF_LABOR = 8; //Constant declaring how many hours of labor are required for 1 coat.
        private const double LABOR_COST_PER_HOUR = 12.50; //Constant declaring the cost of labor per hour.
        
        //Button that takes user input and performs all calculations and output.
        private void calculateButton_Click(object sender, EventArgs e)
        {
            double squareFeet = double.Parse(sqFeetTextBox.Text); //User inputs how many square feet need to be covered.
            double numberOfCoats = double.Parse(coatsTextBox.Text); //User inputs how many coats need to be painted.
            double pricePerGallon = double.Parse(pricePerGallonTextBox.Text); //User inputs the price of paint per gallon.

            double squareFeetToBePainted = squareFeet * numberOfCoats; //Calculates the total square feet that needs to be painted.
            double gallonsOfPaintRequired = Math.Ceiling(squareFeetToBePainted / SQUARE_FEET_COVERED); //Calculates the gallons of paint required. Rounds up to the next integer.
            double hoursOfLaborRequired = squareFeetToBePainted / (SQUARE_FEET_COVERED / HOURS_OF_LABOR); //Calculates the hours of labor required.
            double costOfPaint = gallonsOfPaintRequired * pricePerGallon; //Calculates the cost of the paint.
            double costOfLabor = hoursOfLaborRequired * LABOR_COST_PER_HOUR; //Calculates the cost of the labor.
            double totalCost = costOfLabor + costOfPaint; //Calculates the total cost


            //Outputs all the information 
            sqFeetOutputLabel.Text = squareFeetToBePainted.ToString("n0");
            gallonsRequiredOutputLabel.Text = gallonsOfPaintRequired.ToString();
            hoursRequiredOutputLabel.Text = hoursOfLaborRequired.ToString("n1");
            costOfPaintOutputLabel.Text = costOfPaint.ToString("C");
            costOfLaborOutputLabel.Text = costOfLabor.ToString("C");
            totalCostOutputLabel.Text = totalCost.ToString("C");


        }
    }
}
