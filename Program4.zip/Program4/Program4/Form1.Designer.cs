﻿namespace Program4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.authorLabel = new System.Windows.Forms.Label();
            this.publisherLabel = new System.Windows.Forms.Label();
            this.copyrightLabel = new System.Windows.Forms.Label();
            this.callNumberLabel = new System.Windows.Forms.Label();
            this.bookGroupBox = new System.Windows.Forms.GroupBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.authorTextBox = new System.Windows.Forms.TextBox();
            this.publisherTextBox = new System.Windows.Forms.TextBox();
            this.copyrightYearTextBox = new System.Windows.Forms.TextBox();
            this.callNumberTextBox = new System.Windows.Forms.TextBox();
            this.createBookButton = new System.Windows.Forms.Button();
            this.bookListBox = new System.Windows.Forms.ListBox();
            this.detailsButton = new System.Windows.Forms.Button();
            this.checkOutButton = new System.Windows.Forms.Button();
            this.returnButton = new System.Windows.Forms.Button();
            this.bookGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(6, 19);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(27, 13);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Title";
            // 
            // authorLabel
            // 
            this.authorLabel.AutoSize = true;
            this.authorLabel.Location = new System.Drawing.Point(6, 45);
            this.authorLabel.Name = "authorLabel";
            this.authorLabel.Size = new System.Drawing.Size(38, 13);
            this.authorLabel.TabIndex = 1;
            this.authorLabel.Text = "Author";
            // 
            // publisherLabel
            // 
            this.publisherLabel.AutoSize = true;
            this.publisherLabel.Location = new System.Drawing.Point(6, 71);
            this.publisherLabel.Name = "publisherLabel";
            this.publisherLabel.Size = new System.Drawing.Size(50, 13);
            this.publisherLabel.TabIndex = 2;
            this.publisherLabel.Text = "Publisher";
            // 
            // copyrightLabel
            // 
            this.copyrightLabel.AutoSize = true;
            this.copyrightLabel.Location = new System.Drawing.Point(6, 97);
            this.copyrightLabel.Name = "copyrightLabel";
            this.copyrightLabel.Size = new System.Drawing.Size(76, 13);
            this.copyrightLabel.TabIndex = 3;
            this.copyrightLabel.Text = "Copyright Year";
            // 
            // callNumberLabel
            // 
            this.callNumberLabel.AutoSize = true;
            this.callNumberLabel.Location = new System.Drawing.Point(6, 123);
            this.callNumberLabel.Name = "callNumberLabel";
            this.callNumberLabel.Size = new System.Drawing.Size(64, 13);
            this.callNumberLabel.TabIndex = 4;
            this.callNumberLabel.Text = "Call Number";
            // 
            // bookGroupBox
            // 
            this.bookGroupBox.Controls.Add(this.createBookButton);
            this.bookGroupBox.Controls.Add(this.publisherTextBox);
            this.bookGroupBox.Controls.Add(this.copyrightYearTextBox);
            this.bookGroupBox.Controls.Add(this.callNumberTextBox);
            this.bookGroupBox.Controls.Add(this.authorTextBox);
            this.bookGroupBox.Controls.Add(this.titleTextBox);
            this.bookGroupBox.Controls.Add(this.titleLabel);
            this.bookGroupBox.Controls.Add(this.callNumberLabel);
            this.bookGroupBox.Controls.Add(this.authorLabel);
            this.bookGroupBox.Controls.Add(this.copyrightLabel);
            this.bookGroupBox.Controls.Add(this.publisherLabel);
            this.bookGroupBox.Location = new System.Drawing.Point(26, 31);
            this.bookGroupBox.Name = "bookGroupBox";
            this.bookGroupBox.Size = new System.Drawing.Size(200, 180);
            this.bookGroupBox.TabIndex = 5;
            this.bookGroupBox.TabStop = false;
            this.bookGroupBox.Text = "Enter Book Information";
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(94, 16);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(100, 20);
            this.titleTextBox.TabIndex = 5;
            // 
            // authorTextBox
            // 
            this.authorTextBox.Location = new System.Drawing.Point(94, 42);
            this.authorTextBox.Name = "authorTextBox";
            this.authorTextBox.Size = new System.Drawing.Size(100, 20);
            this.authorTextBox.TabIndex = 6;
            // 
            // publisherTextBox
            // 
            this.publisherTextBox.Location = new System.Drawing.Point(94, 68);
            this.publisherTextBox.Name = "publisherTextBox";
            this.publisherTextBox.Size = new System.Drawing.Size(100, 20);
            this.publisherTextBox.TabIndex = 7;
            // 
            // copyrightYearTextBox
            // 
            this.copyrightYearTextBox.Location = new System.Drawing.Point(94, 94);
            this.copyrightYearTextBox.Name = "copyrightYearTextBox";
            this.copyrightYearTextBox.Size = new System.Drawing.Size(100, 20);
            this.copyrightYearTextBox.TabIndex = 8;
            // 
            // callNumberTextBox
            // 
            this.callNumberTextBox.Location = new System.Drawing.Point(94, 120);
            this.callNumberTextBox.Name = "callNumberTextBox";
            this.callNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.callNumberTextBox.TabIndex = 9;
            // 
            // createBookButton
            // 
            this.createBookButton.Location = new System.Drawing.Point(105, 146);
            this.createBookButton.Name = "createBookButton";
            this.createBookButton.Size = new System.Drawing.Size(75, 23);
            this.createBookButton.TabIndex = 10;
            this.createBookButton.Text = "Create Book";
            this.createBookButton.UseVisualStyleBackColor = true;
            this.createBookButton.Click += new System.EventHandler(this.createBookButton_Click);
            // 
            // bookListBox
            // 
            this.bookListBox.FormattingEnabled = true;
            this.bookListBox.Location = new System.Drawing.Point(251, 37);
            this.bookListBox.Name = "bookListBox";
            this.bookListBox.Size = new System.Drawing.Size(212, 134);
            this.bookListBox.TabIndex = 0;
            // 
            // detailsButton
            // 
            this.detailsButton.Location = new System.Drawing.Point(251, 177);
            this.detailsButton.Name = "detailsButton";
            this.detailsButton.Size = new System.Drawing.Size(80, 23);
            this.detailsButton.TabIndex = 6;
            this.detailsButton.Text = "Details";
            this.detailsButton.UseVisualStyleBackColor = true;
            this.detailsButton.Click += new System.EventHandler(this.detailsButton_Click);
            // 
            // checkOutButton
            // 
            this.checkOutButton.Location = new System.Drawing.Point(251, 206);
            this.checkOutButton.Name = "checkOutButton";
            this.checkOutButton.Size = new System.Drawing.Size(80, 23);
            this.checkOutButton.TabIndex = 7;
            this.checkOutButton.Text = "Check Out";
            this.checkOutButton.UseVisualStyleBackColor = true;
            this.checkOutButton.Click += new System.EventHandler(this.checkOutButton_Click);
            // 
            // returnButton
            // 
            this.returnButton.Location = new System.Drawing.Point(337, 206);
            this.returnButton.Name = "returnButton";
            this.returnButton.Size = new System.Drawing.Size(80, 23);
            this.returnButton.TabIndex = 8;
            this.returnButton.Text = "Return";
            this.returnButton.UseVisualStyleBackColor = true;
            this.returnButton.Click += new System.EventHandler(this.returnButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 250);
            this.Controls.Add(this.returnButton);
            this.Controls.Add(this.checkOutButton);
            this.Controls.Add(this.detailsButton);
            this.Controls.Add(this.bookListBox);
            this.Controls.Add(this.bookGroupBox);
            this.Name = "Form1";
            this.Text = "Program 4";
            this.bookGroupBox.ResumeLayout(false);
            this.bookGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label authorLabel;
        private System.Windows.Forms.Label publisherLabel;
        private System.Windows.Forms.Label copyrightLabel;
        private System.Windows.Forms.Label callNumberLabel;
        private System.Windows.Forms.GroupBox bookGroupBox;
        private System.Windows.Forms.Button createBookButton;
        private System.Windows.Forms.TextBox publisherTextBox;
        private System.Windows.Forms.TextBox copyrightYearTextBox;
        private System.Windows.Forms.TextBox callNumberTextBox;
        private System.Windows.Forms.TextBox authorTextBox;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.ListBox bookListBox;
        private System.Windows.Forms.Button detailsButton;
        private System.Windows.Forms.Button checkOutButton;
        private System.Windows.Forms.Button returnButton;
    }
}

